import { lazy, Suspense } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import Layout from './components/layout/Layout';

const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const ClassesPage = lazy(() => import('./pages/Classes'));
const ClassDetail = lazy(() => import('./pages/ClassDetail'));
const ProgramsPage = lazy(() => import('./pages/Programs'));
const GalleryPage = lazy(() => import('./pages/Gallery'));
const WorkshopsPage = lazy(() => import('./pages/Workshops'));
const TestimonialsPage = lazy(() => import('./pages/Testimonials'));
const ContactPage = lazy(() => import('./pages/Contact'));
const CalligraphyPage = lazy(() => import('./pages/Calligraphy'));
const ArtFormsPage = lazy(() => import('./pages/ArtForms'));

function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-cream">
      <div className="flex flex-col items-center gap-4">
        <div className="w-8 h-8 border-2 border-terracotta/30 border-t-terracotta rounded-full animate-spin" />
        <span className="text-xs tracking-[0.2em] uppercase text-charcoal-warm font-medium">Loading...</span>
      </div>
    </div>
  );
}

function App() {
  const handleOpenEnquiry = () => {};
  const location = useLocation();

  return (
    <Layout>
      <Suspense fallback={<PageLoader />}>
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <Routes location={location}>
              <Route path="/" element={<Home onOpenEnquiry={handleOpenEnquiry} />} />
              <Route path="/about" element={<About />} />
              <Route path="/classes" element={<ClassesPage onOpenEnquiry={handleOpenEnquiry} />} />
              <Route path="/classes/:slug" element={<ClassDetail onOpenEnquiry={handleOpenEnquiry} />} />
              <Route path="/programs" element={<ProgramsPage onOpenEnquiry={handleOpenEnquiry} />} />
              <Route path="/gallery" element={<GalleryPage />} />
              <Route path="/workshops" element={<WorkshopsPage onOpenEnquiry={handleOpenEnquiry} />} />
              <Route path="/testimonials" element={<TestimonialsPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/calligraphy" element={<CalligraphyPage onOpenEnquiry={handleOpenEnquiry} />} />
              <Route path="/art-forms" element={<ArtFormsPage />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </Suspense>
    </Layout>
  );
}

export default App;
