import { motion } from 'framer-motion';
import { galleryCategories, type GalleryCategory } from '../../data/gallery';

interface GalleryFilterProps {
  active: GalleryCategory | 'all';
  onChange: (cat: GalleryCategory | 'all') => void;
}

export default function GalleryFilter({ active, onChange }: GalleryFilterProps) {
  return (
    <div className="flex flex-wrap justify-center gap-2 mb-8 md:mb-12">
      {galleryCategories.map(filter => (
        <button
          key={filter.id}
          onClick={() => onChange(filter.id)}
          className={`relative px-4 py-2 rounded-full text-xs tracking-wide transition-all duration-300 ${active === filter.id ? 'text-cream' : 'text-charcoal-warm hover:text-espresso bg-ivory border border-sand/30 hover:border-sand/60'}`}
        >
          {active === filter.id && (
            <motion.div layoutId="galleryFilter" className="absolute inset-0 bg-espresso rounded-full" transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }} />
          )}
          <span className="relative z-10">{filter.label}</span>
        </button>
      ))}
    </div>
  );
}
