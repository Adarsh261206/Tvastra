import { motion, AnimatePresence } from 'framer-motion';
import { Eye } from 'lucide-react';
import type { GalleryItem } from '../../data/gallery';

interface GalleryGridProps {
  items: GalleryItem[];
  onImageClick: (item: GalleryItem) => void;
}

export default function GalleryGrid({ items, onImageClick }: GalleryGridProps) {
  return (
    <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 md:gap-5">
      <AnimatePresence mode="popLayout">
        {items.map(item => (
          <motion.div
            key={item.id}
            layout
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.4 }}
            className="group relative break-inside-avoid mb-4 md:mb-5 cursor-pointer"
            onClick={() => onImageClick(item)}
          >
            <div className="relative overflow-hidden rounded-xl bg-parchment">
              <div
                className="w-full bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                style={{
                  backgroundImage: `url(${item.image})`,
                  paddingBottom: item.aspect === 'portrait' ? '130%' : item.aspect === 'landscape' ? '70%' : '100%'
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-cream font-medium text-sm">{item.title}</h4>
                    <p className="text-cream/60 text-xs">{item.category}</p>
                  </div>
                  <Eye className="w-4 h-4 text-cream/80" />
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
