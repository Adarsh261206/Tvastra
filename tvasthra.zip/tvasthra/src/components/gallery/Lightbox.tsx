import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import type { GalleryItem } from '../../data/gallery';

interface LightboxProps {
  item: GalleryItem | null;
  items: GalleryItem[];
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export default function Lightbox({ item, items, onClose, onPrev, onNext }: LightboxProps) {
  if (!item) return null;
  const idx = items.findIndex(i => i.id === item.id);

  return (
    <AnimatePresence>
      {item && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-espresso/90 backdrop-blur-sm p-4"
          onClick={onClose}
        >
          <button onClick={onClose} className="absolute top-4 right-4 text-cream/60 hover:text-cream transition-colors z-10">
            <X className="w-7 h-7" />
          </button>
          {idx > 0 && (
            <button onClick={e => { e.stopPropagation(); onPrev(); }} className="absolute left-4 text-cream/60 hover:text-cream transition-colors z-10">
              <ChevronLeft className="w-8 h-8" />
            </button>
          )}
          {idx < items.length - 1 && (
            <button onClick={e => { e.stopPropagation(); onNext(); }} className="absolute right-4 text-cream/60 hover:text-cream transition-colors z-10">
              <ChevronRight className="w-8 h-8" />
            </button>
          )}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="relative max-w-4xl w-full bg-cream rounded-2xl overflow-hidden shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="relative">
              <div className="w-full bg-cover bg-center bg-no-repeat" style={{ backgroundImage: `url(${item.image})`, minHeight: '350px', maxHeight: '65vh' }} />
            </div>
            <div className="p-6">
              <h3 className="font-display text-xl text-espresso">{item.title}</h3>
              <p className="text-xs text-terracotta mt-1">{item.category}</p>
              <p className="text-sm text-charcoal-warm mt-2">{item.description}</p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
