import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function CalligraphySection() {
  return (
    <section className="section-gap bg-cream">
      <div className="container-main">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7 }}
          >
            <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">
              Calligraphy & Handwriting
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-espresso leading-[1.1] mb-5">
              Turn Letters
              <br />
              Into Art.
            </h2>
            <p className="text-charcoal-warm text-sm leading-relaxed mb-6">
              The art of beautiful writing. Our calligraphy and handwriting programs explore letterforms, stroke techniques, and the meditative practice of turning letters into works of art.
            </p>
            <div className="space-y-3 mb-8">
              {['Brush Pen & Cut Nib Calligraphy', 'Copperplate & Devanagari Styles', 'Handwriting Improvement', 'Creative Lettering & Composition'].map((item, i) => (
                <div key={i} className="flex items-center gap-3 text-sm text-charcoal-warm">
                  <div className="w-1 h-1 rounded-full bg-terracotta" />
                  {item}
                </div>
              ))}
            </div>
            <Link
              to="/calligraphy"
              className="inline-flex items-center px-6 py-3 bg-espresso text-cream rounded-full text-sm font-medium hover:bg-espresso-light transition-all duration-300"
            >
              Explore Calligraphy
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden aspect-[4/5] bg-parchment">
              <img
                src="https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&h=1000&fit=crop"
                alt="Calligraphy artwork"
                loading="lazy"
                decoding="async"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/15 to-transparent" />
            </div>
            <div className="absolute -bottom-4 -left-4 w-24 h-24 rounded-xl bg-terracotta/8 -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
