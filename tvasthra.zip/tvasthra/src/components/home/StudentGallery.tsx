import { useState } from 'react';
import { Link } from 'react-router-dom';

import SectionLabel from '../ui/SectionLabel';
import SectionHeader from '../ui/SectionHeader';
import GalleryFilter from '../gallery/GalleryFilter';
import GalleryGrid from '../gallery/GalleryGrid';
import Lightbox from '../gallery/Lightbox';
import { galleryItems } from '../../data/gallery';
import type { GalleryCategory, GalleryItem } from '../../data/gallery';

export default function StudentGallery() {
  const [activeFilter, setActiveFilter] = useState<GalleryCategory | 'all'>('all');
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  const filteredItems = activeFilter === 'all'
    ? galleryItems
    : galleryItems.filter(item => item.category === activeFilter);

  const handlePrev = () => {
    if (!selectedItem) return;
    const idx = filteredItems.findIndex(i => i.id === selectedItem.id);
    setSelectedItem(filteredItems[idx > 0 ? idx - 1 : filteredItems.length - 1]);
  };

  const handleNext = () => {
    if (!selectedItem) return;
    const idx = filteredItems.findIndex(i => i.id === selectedItem.id);
    setSelectedItem(filteredItems[idx < filteredItems.length - 1 ? idx + 1 : 0]);
  };

  return (
    <section className="py-24 md:py-32 bg-cream-warm">
      <div className="container mx-auto px-6 md:px-8 lg:px-12">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-8">
          <div>
            <SectionLabel>From Our Studio</SectionLabel>
            <SectionHeader
              title="Made By Our Students"
              subtitle="A glimpse into the creative work produced across different art forms."
              align="left"
            />
          </div>
          <Link
            to="/gallery"
            className="mt-6 md:mt-0 text-xs font-medium text-espresso tracking-wide uppercase hover:text-terracotta transition-colors duration-300 flex-shrink-0"
          >
            Full Gallery
          </Link>
        </div>

        <GalleryFilter active={activeFilter} onChange={setActiveFilter} />
        <GalleryGrid items={filteredItems} onImageClick={setSelectedItem} />
      </div>

      <Lightbox
        item={selectedItem}
        items={filteredItems}
        onClose={() => setSelectedItem(null)}
        onPrev={handlePrev}
        onNext={handleNext}
      />
    </section>
  );
}
