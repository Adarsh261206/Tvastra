import { motion } from 'framer-motion';

const features = [
  { number: '01', title: 'Hands-On Learning', description: 'Students learn through actual practice and creative activities, not just theory.' },
  { number: '02', title: 'Personal Guidance', description: 'Individual attention and guidance focused on each student\'s growth and development.' },
  { number: '03', title: 'Creative Confidence', description: 'We encourage experimentation, risk-taking, and expressing unique ideas.' },
  { number: '04', title: 'Multiple Art Forms', description: 'Explore traditional and contemporary art forms under one roof.' },
  { number: '05', title: 'Offline Studio Experience', description: 'A physical creative space where students learn, interact, and create together.' },
  { number: '06', title: 'Programs For Every Age', description: 'Thoughtfully designed programs for kids, teens, and adults.' },
];

export default function WhyTvasthra() {
  return (
    <section className="section-gap bg-cream-warm">
      <div className="container-main">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
          <div>
            <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">
              Why TVASTRA
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-espresso leading-[1.1] mb-5">
              Why Create
              <br />
              With TVASTRA?
            </h2>
            <p className="text-charcoal-warm text-sm leading-relaxed">
              More than just classes — a creative experience that inspires and transforms.
            </p>
          </div>

          <div>
            {features.map((feature, index) => (
              <motion.div
                key={feature.number}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.06 }}
                className="py-5 border-b border-espresso/[0.06] last:border-b-0"
              >
                <div className="flex items-start gap-5">
                  <span className="font-display text-2xl md:text-3xl text-terracotta/30 flex-shrink-0 mt-0.5">
                    {feature.number}
                  </span>
                  <div>
                    <h3 className="font-display text-lg md:text-xl text-espresso mb-1">{feature.title}</h3>
                    <p className="text-charcoal-warm text-sm leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
