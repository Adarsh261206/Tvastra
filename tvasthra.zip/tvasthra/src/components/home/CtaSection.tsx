import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { openWhatsApp } from '../../lib/whatsapp';

export default function CtaSection() {
  return (
    <section className="relative section-gap bg-cream overflow-hidden">
      {/* Subtle decorative background */}
      <div className="absolute top-10 left-10 w-64 h-64 bg-terracotta/5 rounded-full blur-3xl" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-sage/5 rounded-full blur-3xl" />

      <div className="container-main relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-4">Start Today</span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-espresso leading-[1.1] mb-5">
              Take the First Step Into
              <br />
              Your Creative Journey.
            </h2>
            <p className="text-charcoal-warm text-sm leading-relaxed mb-8 max-w-md mx-auto">
              Explore a class, visit the studio, or simply ask us about the right program for you.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="flex flex-col sm:flex-row gap-3 justify-center"
          >
            <button
              onClick={() => openWhatsApp()}
              className="inline-flex items-center justify-center px-7 py-3.5 bg-espresso text-cream rounded-full text-sm font-medium hover:bg-espresso-light transition-all duration-300 hover:shadow-lg hover:shadow-espresso/10 active:scale-[0.97]"
            >
              Join a Class
            </button>
            <Link
              to="/contact"
              className="inline-flex items-center justify-center px-7 py-3.5 bg-espresso/10 backdrop-blur-lg text-espresso border border-espresso/15 rounded-full text-sm font-medium transition-all duration-300 hover:bg-espresso/18"
            >
              Contact Studio
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
