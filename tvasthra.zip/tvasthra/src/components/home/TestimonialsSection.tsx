import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { testimonials } from '../../data/testimonials';

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(0);
  const itemsPerPage = typeof window !== 'undefined' && window.innerWidth >= 768 ? 2 : 1;
  const totalPages = Math.ceil(testimonials.length / itemsPerPage);

  useEffect(() => {
    const timer = setInterval(() => {
      setDirection(1);
      setCurrent(prev => (prev + 1) % totalPages);
    }, 7000);
    return () => clearInterval(timer);
  }, [totalPages]);

  const goPrev = () => { setDirection(-1); setCurrent(prev => (prev - 1 + totalPages) % totalPages); };
  const goNext = () => { setDirection(1); setCurrent(prev => (prev + 1) % totalPages); };

  const start = current * itemsPerPage;
  const visible = testimonials.slice(start, start + itemsPerPage);

  return (
    <section className="section-gap bg-espresso">
      <div className="container-main">
        <div className="text-center mb-12 md:mb-16">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta-light font-medium mb-4">
            From Our Community
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-cream leading-[1.1] mb-4">
            Stories From
            <br />
            Our Creative Community.
          </h2>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={current}
              custom={direction}
              initial={{ opacity: 0, x: direction * 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: direction * -40 }}
              transition={{ duration: 0.4 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-5"
            >
              {visible.map(t => (
                <div
                  key={t.id}
                  className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6 transition-all duration-300 hover:bg-white/8"
                >
                  <p className="text-cream/80 text-sm leading-relaxed mb-5 italic">
                    "{t.quote}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-terracotta/20 flex items-center justify-center">
                      <span className="text-xs font-medium text-terracotta-light">{t.name.charAt(0)}</span>
                    </div>
                    <div>
                      <div className="text-cream text-sm font-medium">{t.name}</div>
                      <div className="text-cream/50 text-xs">{t.role === 'parent' ? 'Parent' : 'Student'} · {t.program}</div>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4 mt-10">
            <button onClick={goPrev} className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-cream/50 hover:text-cream hover:border-white/30 transition-all">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="flex gap-1.5">
              {Array.from({ length: totalPages }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => { setDirection(i > current ? 1 : -1); setCurrent(i); }}
                  className={`h-1.5 rounded-full transition-all duration-300 ${i === current ? 'bg-terracotta w-5' : 'bg-white/20 w-1.5'}`}
                />
              ))}
            </div>
            <button onClick={goNext} className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-cream/50 hover:text-cream hover:border-white/30 transition-all">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
