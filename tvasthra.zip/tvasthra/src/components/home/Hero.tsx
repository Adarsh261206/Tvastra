import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const carouselImages = [
  { label: 'Painting', image: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=300&h=300&fit=crop&q=75' },
  { label: 'Sketching', image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=300&h=300&fit=crop&q=75' },
  { label: 'Calligraphy', image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=300&h=300&fit=crop&q=75' },
  { label: 'Drawing', image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=300&h=300&fit=crop&q=75' },
  { label: 'Art Studio', image: 'https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=300&h=300&fit=crop&q=75' },
  { label: 'Brushwork', image: 'https://images.unsplash.com/photo-1596548438137-d51ea5c83ca5?w=300&h=300&fit=crop&q=75' },
  { label: 'Creative Work', image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=300&h=300&fit=crop&q=70' },
  { label: 'Hand Lettering', image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=300&h=300&fit=crop&q=70' },
];

const loopImages = [...carouselImages, ...carouselImages, ...carouselImages];

export default function Hero() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [imgLoaded, setImgLoaded] = useState(false);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    let animId: number;
    let scrollPos = 0;
    const speed = 0.5;

    const animate = () => {
      scrollPos += speed;
      if (scrollPos >= el.scrollWidth / 3) {
        scrollPos = 0;
      }
      el.scrollLeft = scrollPos;
      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <section className="relative h-screen flex flex-col bg-cream overflow-hidden">
      {/* Full-screen Background Image — img tag for fetchpriority */}
      <img
        src="https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=1920&h=1080&fit=crop&q=85"
        alt=""
        fetchPriority="high"
        decoding="async"
        onLoad={() => setImgLoaded(true)}
        className={`absolute inset-0 w-full h-full object-cover object-[center_30%] sm:object-center transition-opacity duration-700 ${imgLoaded ? 'opacity-100' : 'opacity-0'}`}
      />

      {/* Warm cream overlay */}
      <div
        className="absolute inset-0 pointer-events-none z-[2]"
        style={{
          background: 'linear-gradient(180deg, rgba(250,247,242,0.65) 0%, rgba(250,247,242,0.25) 25%, rgba(250,247,242,0.08) 45%, rgba(250,247,242,0.18) 65%, rgba(250,247,242,0.55) 100%)'
        }}
      />

      {/* Subtle vertical grid lines */}
      <div className="absolute inset-0 pointer-events-none z-[3] max-sm:hidden">
        <div className="absolute top-0 bottom-0 left-[20%] w-px bg-espresso/[0.06]" />
        <div className="absolute top-0 bottom-0 left-[40%] w-px bg-espresso/[0.06]" />
        <div className="absolute top-0 bottom-0 left-[60%] w-px bg-espresso/[0.06]" />
        <div className="absolute top-0 bottom-0 left-[80%] w-px bg-espresso/[0.06]" />
      </div>

      {/* Main Content */}
      <div className="relative z-[4] flex-1 flex flex-col justify-center container mx-auto px-6 lg:px-10 pt-24 sm:pt-28 pb-64 sm:pb-72">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-5"
          >
            <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium bg-cream/40 backdrop-blur-sm border border-terracotta/15 rounded-full px-4 py-1.5">
              TVASTRA Art Studio
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-[2.8rem] sm:text-[3rem] md:text-[3.5rem] lg:text-[4.5rem] xl:text-[5.5rem] leading-[1.05] sm:leading-[1.02] text-espresso text-balance mb-8"
          >
            Where{' '}
            <span className="italic text-terracotta">Imagination</span>
            <br />
            Takes Shape.
          </motion.h1>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="flex flex-wrap items-center gap-3 mb-8"
          >
            <Link
              to="/classes"
              className="inline-flex items-center px-6 py-3 sm:px-7 sm:py-3.5 bg-espresso text-cream rounded-full text-sm font-medium font-body tracking-wide transition-all duration-300 hover:bg-espresso-light hover:shadow-lg hover:shadow-espresso/15 active:scale-[0.97]"
            >
              Explore Classes
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 sm:px-7 sm:py-3.5 bg-espresso/10 backdrop-blur-lg text-espresso border border-espresso/15 rounded-full text-sm font-medium font-body tracking-wide transition-all duration-300 hover:bg-espresso/20 hover:border-espresso/25"
            >
              Enquire Now
            </Link>
          </motion.div>

          {/* Info Pills */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.55 }}
            className="flex flex-wrap gap-2.5"
          >
            <span className="inline-flex items-center gap-2 px-3.5 py-2 bg-cream/30 backdrop-blur-sm border border-cream-dark/40 rounded-full text-[11px] sm:text-xs text-espresso/80 font-body">
              <span className="w-1.5 h-1.5 rounded-full bg-terracotta" />
              Hands-On Creative Learning
            </span>
            <span className="inline-flex items-center gap-2 px-3.5 py-2 bg-cream/30 backdrop-blur-sm border border-cream-dark/40 rounded-full text-[11px] sm:text-xs text-espresso/80 font-body">
              <span className="w-1.5 h-1.5 rounded-full bg-sage" />
              Kids · Teens · Adults
            </span>
          </motion.div>
        </div>
      </div>

      {/* Bottom Scrolling Circular Image Carousel */}
      <div className="absolute bottom-2 sm:bottom-4 left-0 right-0 z-[4]">
        <div
          ref={scrollRef}
          className="flex items-end gap-4 sm:gap-5 md:gap-6 px-6 overflow-hidden"
          style={{ scrollBehavior: 'auto' }}
        >
          {loopImages.map((img, i) => (
            <div
              key={`${img.label}-${i}`}
              className="relative group flex-shrink-0"
            >
              {/* Perfect circle — same width AND height */}
              <div className="w-36 h-36 sm:w-40 sm:h-40 md:w-44 md:h-44 lg:w-48 lg:h-48 rounded-full overflow-hidden shadow-[0_8px_24px_rgba(0,0,0,0.18)] sm:shadow-[0_12px_36px_rgba(0,0,0,0.22)] transition-shadow duration-500 hover:shadow-[0_20px_50px_rgba(0,0,0,0.3)]">
                <img
                  src={img.image}
                  alt={img.label}
                  loading={i < 3 ? 'eager' : 'lazy'}
                  decoding="async"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
              </div>

              {/* Hover overlay + label ON the circle */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-t from-espresso/75 via-espresso/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400 pointer-events-none flex items-end justify-center pb-4">
                <span className="text-cream text-[11px] sm:text-xs font-medium tracking-wide drop-shadow-lg">
                  {img.label}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
