import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function AgeGroupsSection() {
  const groups = [
    {
      title: 'Kids',
      action: 'Explore',
      description: 'Creative exploration through drawing, painting, crafts, and imagination-based activities.',
      image: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=600&h=800&fit=crop',
      link: '/programs',
    },
    {
      title: 'Teens',
      action: 'Develop',
      description: 'Skill development through sketching, painting, calligraphy, and finding your artistic voice.',
      image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&h=800&fit=crop',
      link: '/programs',
    },
    {
      title: 'Adults',
      action: 'Express',
      description: 'Creative practice, hobbies, and workshops in a welcoming environment.',
      image: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=600&h=800&fit=crop',
      link: '/programs',
    },
  ];

  return (
    <section className="section-gap bg-cream">
      <div className="container-main">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.6 }}
          className="mb-12 md:mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-espresso leading-[1.1]">
            Creativity Has
            <br />
            No Age Limit.
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6">
          {groups.map((group, i) => (
            <motion.div
              key={group.title}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
            >
              <Link
                to={group.link}
                className="group block relative rounded-2xl overflow-hidden aspect-[3/4] bg-parchment"
              >
                <img
                  src={group.image}
                  alt={group.title}
                  loading="lazy"
                  decoding="async"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-espresso/70 via-espresso/15 to-transparent" />

                {/* Top badge */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 shadow-sm">
                  <span className="text-[10px] font-medium text-espresso tracking-wide uppercase">{group.title}</span>
                </div>

                {/* Bottom content */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-display text-2xl md:text-3xl text-cream mb-1">{group.title}</h3>
                      <p className="text-cream/70 text-xs">{group.description}</p>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
