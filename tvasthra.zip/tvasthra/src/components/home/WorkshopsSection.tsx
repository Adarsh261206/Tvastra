
import { Link } from 'react-router-dom';
import SectionLabel from '../ui/SectionLabel';
import SectionHeader from '../ui/SectionHeader';
import WorkshopCard from '../cards/WorkshopCard';
import { workshops } from '../../data/workshops';

interface WorkshopsSectionProps {
  onOpenEnquiry: (title?: string) => void;
}

export default function WorkshopsSection({ onOpenEnquiry }: WorkshopsSectionProps) {
  const upcoming = workshops.filter(w => w.status === 'upcoming').slice(0, 3);

  return (
    <section className="py-24 md:py-32 bg-cream">
      <div className="container mx-auto px-6 md:px-8 lg:px-12">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 md:mb-16">
          <div>
            <SectionLabel>Workshops & Events</SectionLabel>
            <SectionHeader
              title="More Than Just Classes"
              subtitle="Special creative experiences that bring our community together."
              align="left"
            />
          </div>
          <Link
            to="/workshops"
            className="mt-6 md:mt-0 text-xs font-medium text-espresso tracking-wide uppercase hover:text-terracotta transition-colors duration-300 flex-shrink-0"
          >
            All Workshops
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {upcoming.map((workshop, index) => (
            <WorkshopCard
              key={workshop.id}
              workshop={workshop}
              delay={index * 0.1}
              onEnquire={(title) => onOpenEnquiry(title)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
