import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function ArtFormsSplit() {
  return (
    <section className="section-gap bg-cream-warm">
      <div className="container-main">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14 md:mb-16"
        >
          <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-espresso leading-[1.1]">
            From Tradition
            <br />
            to Experimentation.
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6">
          {/* Traditional Art */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Link
              to="/art-forms"
              className="group block relative overflow-hidden rounded-2xl bg-parchment"
            >
              <div className="relative h-80 md:h-[30rem] overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=800&h=1000&fit=crop"
                  alt="Traditional Indian art"
                  loading="lazy"
                  decoding="async"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-espresso/75 via-espresso/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-7 md:p-8">
                  <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium">Heritage</span>
                  <h3 className="font-display text-2xl md:text-3xl text-cream mt-2 mb-3">Traditional Art</h3>
                  <p className="text-cream/70 text-sm leading-relaxed mb-4 max-w-sm">
                    Explore the rich heritage of Indian art forms. From Madhubani to Warli, discover techniques passed down through generations.
                  </p>
                  <span className="text-cream text-sm font-medium">Explore</span>
                </div>
              </div>
            </Link>
          </motion.div>

          {/* Modern Art */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <Link
              to="/art-forms"
              className="group block relative overflow-hidden rounded-2xl bg-parchment"
            >
              <div className="relative h-80 md:h-[30rem] overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800&h=1000&fit=crop"
                  alt="Modern contemporary art"
                  loading="lazy"
                  decoding="async"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-espresso/75 via-espresso/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-7 md:p-8">
                  <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium">Contemporary</span>
                  <h3 className="font-display text-2xl md:text-3xl text-cream mt-2 mb-3">Modern Art</h3>
                  <p className="text-cream/70 text-sm leading-relaxed mb-4 max-w-sm">
                    Push creative boundaries with abstract expression, mixed media, and contemporary approaches to artistic creation.
                  </p>
                  <span className="text-cream text-sm font-medium">Explore</span>
                </div>
              </div>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
