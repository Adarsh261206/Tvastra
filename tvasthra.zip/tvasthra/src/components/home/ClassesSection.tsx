import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

import { classes } from '../../data/classes';

export default function ClassesSection() {
  const featuredClasses = classes.slice(0, 4);

  const images = [
    'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=600&h=800&fit=crop',
    'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=600&h=800&fit=crop',
    'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=800&fit=crop',
    'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=600&h=800&fit=crop',
  ];

  return (
    <section className="section-gap bg-cream-warm">
      <div className="container-main">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 md:mb-16">
          <div>
            <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-3">
              Explore
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-espresso leading-[1.1]">
              Creative Classes
              <br />
              For Curious Minds.
            </h2>
          </div>
          <Link
            to="/classes"
            className="mt-6 md:mt-0 text-xs font-medium text-espresso tracking-wide uppercase hover:text-terracotta transition-colors duration-300 flex-shrink-0"
          >
            View All
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
          {featuredClasses.map((cls, i) => (
            <motion.div
              key={cls.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
            >
              <Link
                to={`/classes/${cls.slug}`}
                className="group block"
              >
                <div className="relative rounded-2xl overflow-hidden aspect-[3/4] bg-parchment mb-4">
                  <img
                    src={images[i]}
                    alt={cls.name}
                    loading="lazy"
                    decoding="async"
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-espresso/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                </div>
                <div>
                  <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium">{cls.ageGroups[0]}</span>
                  <h3 className="font-display text-lg text-espresso mt-1 group-hover:text-terracotta transition-colors duration-300">{cls.name}</h3>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
