import { motion } from 'framer-motion';
import SectionLabel from '../ui/SectionLabel';

import { Link } from 'react-router-dom';

export default function IntroSection() {
  return (
    <section className="section-gap bg-cream">
      <div className="container-main">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Stacked Editorial Images */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="relative">
              {/* Main image */}
              <div className="w-full h-[24rem] md:h-[30rem] rounded-lg overflow-hidden bg-parchment relative">
                <img
                  src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=800&h=1000&fit=crop"
                  alt="Art studio"
                  loading="lazy"
                  decoding="async"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-espresso/20 to-transparent" />
                {/* Badge */}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-sm flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-terracotta" />
                  <span className="text-[10px] font-medium text-espresso tracking-wide uppercase">Studio</span>
                </div>
              </div>

              {/* Second image — offset */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="absolute -bottom-8 -right-6 md:-right-10 w-40 md:w-48 h-48 md:h-56 rounded-lg overflow-hidden shadow-lg border-2 border-cream"
              >
                <img
                  src="https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=400&h=400&fit=crop"
                  alt="Painting detail"
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                />
              </motion.div>

              {/* Third image — offset */}
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.35 }}
                className="absolute -top-6 -left-4 md:-left-8 w-28 md:w-36 h-36 md:h-44 rounded-lg overflow-hidden shadow-lg border-2 border-cream"
              >
                <img
                  src="https://images.unsplash.com/photo-1455390582262-044cdead277a?w=400&h=400&fit=crop"
                  alt="Calligraphy"
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                />
              </motion.div>
            </div>
          </motion.div>

          {/* Right: Content */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, delay: 0.15 }}
          >
            <SectionLabel>About TVASTRA</SectionLabel>
            <h2 className="font-display text-3xl md:text-4xl lg:text-[2.75rem] text-espresso leading-[1.1] mb-5">
              A Studio Built
              <br />
              Around Creativity.
            </h2>
            <p className="text-charcoal-warm text-sm leading-relaxed mb-3">
              TVASTRA is a space where creativity becomes a practice. Through hands-on classes, workshops, and artistic exploration, students learn to observe, experiment, create, and express.
            </p>
            <p className="text-charcoal-warm text-sm leading-relaxed mb-8">
              Every session is designed to help you discover your creative voice and develop skills that last a lifetime.
            </p>

            {/* Info blocks */}
            <div className="grid grid-cols-3 gap-4 py-5 border-y border-espresso/[0.08] mb-8">
              <div>
                <div className="text-[10px] tracking-[0.15em] uppercase text-terracotta font-medium mb-1">Hands-On</div>
                <div className="font-display text-sm md:text-base text-espresso">Creative Learning</div>
              </div>
              <div>
                <div className="text-[10px] tracking-[0.15em] uppercase text-terracotta font-medium mb-1">Multiple</div>
                <div className="font-display text-sm md:text-base text-espresso">Art Forms</div>
              </div>
              <div>
                <div className="text-[10px] tracking-[0.15em] uppercase text-terracotta font-medium mb-1">All Ages</div>
                <div className="font-display text-sm md:text-base text-espresso">Kids · Teens · Adults</div>
              </div>
            </div>

            <Link
              to="/about"
              className="text-xs font-medium text-espresso tracking-wide uppercase hover:text-terracotta transition-colors duration-300"
            >
              Discover TVASTRA
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
