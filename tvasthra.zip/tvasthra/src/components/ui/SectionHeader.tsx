import { motion } from 'framer-motion';
import SectionLabel from './SectionLabel';

interface SectionHeaderProps {
  label?: string;
  title: string;
  subtitle?: string;
  align?: 'left' | 'center';
  light?: boolean;
  className?: string;
}

export default function SectionHeader({ label, title, subtitle, align = 'center', light = false, className = '' }: SectionHeaderProps) {
  return (
    <div className={`${align === 'center' ? 'text-center' : 'text-left'} ${className}`}>
      {label && <SectionLabel light={light}>{label}</SectionLabel>}
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-50px' }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className={`font-display text-3xl md:text-4xl lg:text-5xl leading-[1.1] ${light ? 'text-cream' : 'text-espresso'}`}
      >
        {title.split('\n').map((line, i) => (
          <span key={i}>{line}{i < title.split('\n').length - 1 && <br />}</span>
        ))}
      </motion.h2>
      {subtitle && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className={`mt-4 md:mt-5 text-sm md:text-base leading-relaxed max-w-xl ${align === 'center' ? 'mx-auto' : ''} ${light ? 'text-sand-light' : 'text-charcoal-warm'}`}
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}
