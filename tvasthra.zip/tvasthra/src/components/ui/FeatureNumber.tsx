import { motion } from 'framer-motion';

interface FeatureNumberProps {
  number: string;
  title: string;
  description: string;
  delay?: number;
}

export default function FeatureNumber({ number, title, description, delay = 0 }: FeatureNumberProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="group flex gap-6 py-6 border-b border-sand/40 last:border-b-0"
    >
      <span className="text-xs text-terracotta font-medium mt-1 w-8 flex-shrink-0">{number}</span>
      <div>
        <h4 className="font-display text-lg md:text-xl text-espresso mb-1 group-hover:text-terracotta transition-colors">{title}</h4>
        <p className="text-sm text-charcoal-warm leading-relaxed">{description}</p>
      </div>
    </motion.div>
  );
}
