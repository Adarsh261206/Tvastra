import { motion } from 'framer-motion';
import { 
  Paintbrush, Users, Lightbulb, Palette, 
  Building, Heart
} from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  'Paintbrush': <Paintbrush className="w-6 h-6" />,
  'Users': <Users className="w-6 h-6" />,
  'Lightbulb': <Lightbulb className="w-6 h-6" />,
  'Palette': <Palette className="w-6 h-6" />,
  'Building': <Building className="w-6 h-6" />,
  'Heart': <Heart className="w-6 h-6" />,
};

interface FeatureBlockProps {
  icon: string;
  title: string;
  description: string;
  delay?: number;
}

export default function FeatureBlock({ icon, title, description, delay = 0 }: FeatureBlockProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="text-center p-6 md:p-8"
    >
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-terracotta/10 text-terracotta mb-4">
        {iconMap[icon] || <Palette className="w-6 h-6" />}
      </div>
      <h3 className="font-display text-xl font-bold text-charcoal mb-2">{title}</h3>
      <p className="text-charcoal-light text-sm leading-relaxed">{description}</p>
    </motion.div>
  );
}
