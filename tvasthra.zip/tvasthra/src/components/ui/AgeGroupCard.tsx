import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

interface AgeGroupCardProps {
  title: string;
  subtitle: string;
  description: string;
  image: string;
  link: string;
  delay?: number;
}

export default function AgeGroupCard({ title, subtitle, description, image, link, delay = 0 }: AgeGroupCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay }}
      className="group relative overflow-hidden rounded-2xl bg-parchment"
    >
      <div className="relative h-80 md:h-96 overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" style={{ backgroundImage: `url(${image})` }} />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
          <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium">{subtitle}</span>
          <h3 className="font-display text-3xl md:text-4xl text-cream mt-1 mb-3">{title}</h3>
          <p className="text-cream/70 text-sm leading-relaxed mb-4">{description}</p>
          <Link to={link} className="text-cream text-sm font-medium hover:text-terracotta-light transition-all duration-300">
            Explore
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
