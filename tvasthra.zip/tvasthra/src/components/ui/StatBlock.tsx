import { motion } from 'framer-motion';

interface StatBlockProps {
  value: string;
  label: string;
  delay?: number;
}

export default function StatBlock({ value, label, delay = 0 }: StatBlockProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="text-center"
    >
      <div className="font-display text-3xl md:text-4xl font-bold text-terracotta">{value}</div>
      <div className="mt-2 text-sm md:text-base text-charcoal-light">{label}</div>
    </motion.div>
  );
}
