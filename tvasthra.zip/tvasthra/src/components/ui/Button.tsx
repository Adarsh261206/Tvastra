import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  to?: string;
  onClick?: () => void;
  className?: string;
  showArrow?: boolean;
}

export default function Button({ children, variant = 'primary', size = 'md', to, onClick, className = '', showArrow = false }: ButtonProps) {
  const base = 'inline-flex items-center gap-2 rounded-full font-medium transition-all duration-300 cursor-pointer';
  const variants: Record<string, string> = {
    primary: 'bg-espresso text-cream hover:bg-espresso-light',
    secondary: 'bg-terracotta text-white hover:bg-terracotta-deep',
    outline: 'border border-espresso/20 text-espresso hover:bg-espresso hover:text-cream'
  };
  const sizes: Record<string, string> = {
    sm: 'px-5 py-2 text-xs',
    md: 'px-6 py-3 text-sm',
    lg: 'px-8 py-4 text-sm'
  };
  const cls = `${base} ${variants[variant]} ${sizes[size]} ${className}`;
  const content = <>{children}{showArrow && <ArrowRight className="w-3.5 h-3.5" />}</>;

  if (to) {
    return (
      <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
        <Link to={to} className={cls}>{content}</Link>
      </motion.div>
    );
  }

  return (
    <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={onClick} className={cls}>
      {content}
    </motion.button>
  );
}
