import { motion } from 'framer-motion';

interface SectionLabelProps {
  children: string;
  light?: boolean;
}

export default function SectionLabel({ children, light = false }: SectionLabelProps) {
  return (
    <motion.span
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5 }}
      className={`inline-block text-[10px] md:text-[11px] tracking-[0.2em] uppercase font-medium mb-4 md:mb-5 ${light ? 'text-terracotta-light' : 'text-terracotta'}`}
    >
      {children}
    </motion.span>
  );
}
