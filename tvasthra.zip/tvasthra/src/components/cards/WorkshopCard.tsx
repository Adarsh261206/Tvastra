import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Calendar } from 'lucide-react';
import { openWhatsApp } from '../../lib/whatsapp';
import type { Workshop } from '../../data/workshops';

interface WorkshopCardProps {
  workshop: Workshop;
  delay?: number;
  onEnquire?: (title: string) => void;
}

export default function WorkshopCard({ workshop, delay = 0, onEnquire }: WorkshopCardProps) {
  const isUpcoming = workshop.status === 'upcoming';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="group bg-ivory rounded-2xl overflow-hidden border border-sand/20 hover:border-sand/40 hover:shadow-lg transition-all duration-500"
    >
      {/* Image — clickable to workshops page */}
      <Link to="/workshops" className="block relative h-48 overflow-hidden">
        <img
          src={workshop.image}
          alt={workshop.title}
          loading="lazy"
          decoding="async"
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <div className="absolute top-3 right-3">
          <span className={`px-3 py-1 text-[10px] tracking-wider uppercase rounded-full font-medium ${isUpcoming ? 'bg-sage text-white' : 'bg-charcoal-warm text-cream'}`}>
            {isUpcoming ? 'Upcoming' : 'Completed'}
          </span>
        </div>
      </Link>

      {/* Content */}
      <div className="p-5">
        <span className="text-[10px] tracking-[0.15em] uppercase text-terracotta font-medium">{workshop.type}</span>
        <h4 className="font-display text-lg text-espresso mt-2 mb-2">{workshop.title}</h4>
        <p className="text-sm text-charcoal-warm leading-relaxed mb-4 line-clamp-2">{workshop.description}</p>
        <div className="flex items-center gap-4 text-xs text-charcoal-warm mb-4">
          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{workshop.date}</span>
          <span>{workshop.ageGroup}</span>
        </div>

        {isUpcoming && onEnquire ? (
          <button
            onClick={() => openWhatsApp(workshop.title)}
            className="w-full py-2.5 rounded-full bg-espresso text-cream text-xs font-medium hover:bg-espresso-light transition-colors duration-300"
          >
            Register Interest
          </button>
        ) : (
          <div className="w-full py-2.5 rounded-full bg-parchment text-charcoal-warm text-xs font-medium text-center">Completed</div>
        )}
      </div>
    </motion.div>
  );
}
