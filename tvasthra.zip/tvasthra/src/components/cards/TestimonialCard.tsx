import { motion } from 'framer-motion';
import type { Testimonial } from '../../data/testimonials';

interface TestimonialCardProps {
  testimonial: Testimonial;
  delay?: number;
}

export default function TestimonialCard({ testimonial, delay = 0 }: TestimonialCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="bg-espresso-light/50 rounded-2xl p-6 md:p-8 border border-white/5"
    >
      <div className="font-display text-4xl text-terracotta/30 leading-none mb-4">"</div>
      <p className="text-cream/90 leading-relaxed mb-6 text-sm md:text-base italic">{testimonial.quote}</p>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-terracotta/20 flex items-center justify-center">
          <span className="font-display text-sm font-semibold text-terracotta">{testimonial.name.charAt(0)}</span>
        </div>
        <div>
          <div className="text-cream text-sm font-medium">{testimonial.name}</div>
          <div className="text-cream/50 text-xs">{testimonial.role === 'parent' ? 'Parent' : 'Student'}{testimonial.ageGroup && ` · ${testimonial.ageGroup}`}</div>
        </div>
      </div>
    </motion.div>
  );
}
