import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { openWhatsApp } from '../../lib/whatsapp';
import type { ArtClass } from '../../data/classes';

interface ClassCardProps {
  cls: ArtClass;
  delay?: number;
  onEnquire?: (name: string) => void;
}

export default function ClassCard({ cls, delay = 0, onEnquire }: ClassCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{ duration: 0.5, delay }}
    >
      <Link
        to={`/classes/${cls.slug}`}
        className="group block bg-ivory rounded-2xl overflow-hidden border border-sand/20 hover:border-sand/50 hover:shadow-xl hover:shadow-espresso/5 transition-all duration-500"
      >
        {/* Image */}
        <div className="relative h-56 md:h-64 overflow-hidden">
          <img
            src={cls.image}
            alt={cls.name}
            loading="lazy"
            decoding="async"
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-espresso/40 via-espresso/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />

          {/* Hover arrow */}
          <div className="absolute bottom-4 right-4 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-3 group-hover:translate-y-0 transition-all duration-400 shadow-lg">
            <svg className="w-4 h-4 text-espresso" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 md:p-6">
          <div className="flex items-center gap-2 mb-3">
            {cls.ageGroups.map(g => (
              <span key={g} className="text-[10px] tracking-wider uppercase text-terracotta bg-terracotta/5 px-2 py-0.5 rounded-full">{g}</span>
            ))}
          </div>
          <h3 className="font-display text-xl text-espresso mb-2 group-hover:text-terracotta transition-colors duration-300">{cls.name}</h3>
          <p className="text-sm text-charcoal-warm leading-relaxed mb-4 line-clamp-2">{cls.shortDescription}</p>

          <div className="flex items-center justify-between">
            {/* Learn More — designed as a link */}
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-espresso group-hover:text-terracotta transition-colors duration-300">
              Learn More
              <span className="w-5 h-5 rounded-full bg-espresso/5 group-hover:bg-terracotta/10 flex items-center justify-center transition-all duration-300 group-hover:translate-x-0.5">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </span>
            </span>

            {onEnquire && (
              <button
                onClick={(e) => { e.preventDefault(); e.stopPropagation(); openWhatsApp(cls.name); }}
                className="text-[10px] tracking-wider uppercase px-3 py-1.5 rounded-full border border-espresso/15 text-espresso hover:bg-espresso hover:text-cream transition-all duration-300"
              >
                Enquire
              </button>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
