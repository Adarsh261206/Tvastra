import { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ArrowUpRight, ChevronDown } from 'lucide-react';
import { openWhatsApp } from '../../lib/whatsapp';

interface NavbarProps {
  onOpenEnquiry?: () => void;
}

const navItems = [
  {
    label: 'Home',
    to: '/',
  },
  {
    label: 'About',
    to: '/about',
    children: [
      { label: 'Our Story', to: '/about', desc: 'Learn about TVASTRA and our mission.' },
      { label: 'Programs', to: '/programs', desc: 'Creative programs for every age group.' },
      { label: 'Testimonials', to: '/testimonials', desc: 'Hear from our creative community.' },
    ],
  },
  {
    label: 'Classes',
    to: '/classes',
    children: [
      { label: 'Drawing & Sketching', to: '/classes/drawing', desc: 'Build foundations in line, shape, and form.' },
      { label: 'Painting', to: '/classes/painting', desc: 'Explore color, texture, and expression.' },
      { label: 'Calligraphy', to: '/classes/calligraphy', desc: 'The art of beautiful writing.' },
      { label: 'Handwriting', to: '/classes/handwriting', desc: 'Improve letter consistency and flow.' },
      { label: 'Traditional Art', to: '/classes/traditional-art', desc: 'Heritage art forms and techniques.' },
      { label: 'Modern Art', to: '/classes/modern-art', desc: 'Contemporary creative expression.' },
    ],
  },
  {
    label: 'Gallery',
    to: '/gallery',
  },
  {
    label: 'Workshops',
    to: '/workshops',
  },
  {
    label: 'Contact',
    to: '/contact',
  },
];

export default function Navbar({ onOpenEnquiry: _onOpenEnquiry }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [mobileSubmenu, setMobileSubmenu] = useState<string | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const closeMobile = () => {
    setMobileOpen(false);
    setMobileSubmenu(null);
  };

  return (
    <>
      <motion.header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-700 ease-out ${
          scrolled
            ? 'bg-cream/80 backdrop-blur-xl border-b border-espresso/5 py-3'
            : 'bg-transparent py-5'
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
      >
        <nav className="mx-auto max-w-[90rem] px-5 md:px-8 lg:px-10 flex items-center justify-between">
          {/* Logo */}
          <NavLink to="/" className="flex-shrink-0">
            <span className="font-display text-[1.35rem] font-semibold tracking-[0.06em] text-espresso">
              TVASTRA
            </span>
          </NavLink>

          {/* Desktop Nav — visible from md */}
          <ul className="hidden md:flex items-center gap-1.5">
            {navItems.map((item) => (
              <li
                key={item.to}
                className="relative"
                onMouseEnter={() => item.children && setHoveredItem(item.label)}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `relative flex items-center gap-1 px-4 py-2 rounded-full text-[13px] font-medium font-body transition-all duration-300 backdrop-blur-lg ${
                      isActive && !item.children
                        ? 'bg-espresso text-cream border border-espresso/30 shadow-sm'
                        : hoveredItem === item.label
                        ? 'bg-espresso/10 text-espresso border border-espresso/10'
                        : 'bg-espresso/5 text-espresso/80 border border-espresso/8 hover:bg-espresso/10 hover:text-espresso'
                    }`
                  }
                  end={item.to === '/'}
                  onClick={() => setHoveredItem(null)}
                >
                  {item.label}
                  {item.children && (
                    <ChevronDown className={`w-3 h-3 transition-transform duration-300 ${hoveredItem === item.label ? 'rotate-180' : ''}`} />
                  )}
                </NavLink>

                {/* Dropdown */}
                {item.children && (
                  <div
                    className={`absolute top-full left-1/2 -translate-x-1/2 transition-all duration-200 ${
                      hoveredItem === item.label
                        ? 'opacity-100 visible translate-y-0'
                        : 'opacity-0 invisible translate-y-1 pointer-events-none'
                    }`}
                  >
                    <div className={`bg-cream/95 backdrop-blur-2xl rounded-2xl shadow-[0_20px_60px_rgba(44,24,16,0.12)] border border-espresso/8 overflow-hidden ${
                      item.children.length > 4 ? 'min-w-[36rem]' : 'min-w-[18rem]'
                    }`}>
                      {item.children.length > 4 ? (
                        <div className="flex">
                          <div className="w-[14rem] bg-espresso/[0.03] p-6 border-r border-espresso/5">
                            <div className="text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-2">{item.label}</div>
                            <p className="text-charcoal-warm text-xs leading-relaxed">
                              Explore our creative classes designed for every skill level and age group.
                            </p>
                          </div>
                          <div className="flex-1 p-3">
                            {item.children.map((child) => (
                              <NavLink
                                key={child.to}
                                to={child.to}
                                className="group flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium text-espresso transition-all duration-300 hover:bg-espresso/[0.04]"
                                onClick={() => setHoveredItem(null)}
                              >
                                <div>
                                  <div className="text-sm font-medium">{child.label}</div>
                                  {child.desc && (
                                    <div className="text-[11px] text-charcoal-warm/70 font-normal mt-0.5">{child.desc}</div>
                                  )}
                                </div>
                                <ArrowUpRight className="w-3.5 h-3.5 text-terracotta opacity-0 -translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0" />
                              </NavLink>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="p-3 min-w-[16rem]">
                          {item.children.map((child) => (
                            <NavLink
                              key={child.to}
                              to={child.to}
                              className="group flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-medium text-espresso transition-all duration-300 hover:bg-espresso/[0.04]"
                              onClick={() => setHoveredItem(null)}
                            >
                              <div>
                                <div className="text-sm font-medium">{child.label}</div>
                                {child.desc && (
                                  <div className="text-[11px] text-charcoal-warm/70 font-normal mt-0.5">{child.desc}</div>
                                )}
                              </div>
                              <ArrowUpRight className="w-3.5 h-3.5 text-terracotta opacity-0 -translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0" />
                            </NavLink>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>

          {/* CTA Button — visible from md */}
          <button
            onClick={() => openWhatsApp()}
            className="hidden md:inline-flex items-center px-6 py-2.5 rounded-full bg-espresso text-cream text-[13px] font-medium font-body tracking-wide transition-all duration-300 hover:bg-espresso-light hover:shadow-lg hover:shadow-espresso/10 active:scale-[0.97]"
          >
            Join a Class
          </button>

          {/* Mobile Hamburger — visible below md */}
          <button
            onClick={() => setMobileOpen(true)}
            className="flex md:hidden items-center justify-center w-11 h-11 rounded-full bg-espresso/8 backdrop-blur-lg text-espresso border border-espresso/10 transition-all duration-300 hover:bg-espresso/12"
            aria-label="Open menu"
          >
            <Menu size={20} strokeWidth={1.5} />
          </button>
        </nav>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-[60] bg-cream flex flex-col"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5">
              <NavLink to="/" className="font-display text-[1.35rem] font-semibold tracking-[0.06em] text-espresso" onClick={closeMobile}>
                TVASTRA
              </NavLink>
              <button onClick={closeMobile} className="w-11 h-11 rounded-full flex items-center justify-center bg-espresso/8 text-espresso" aria-label="Close menu">
                <X size={20} strokeWidth={1.5} />
              </button>
            </div>

            {/* Nav Items */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              <ul className="space-y-1">
                {navItems.map((item, i) => (
                  <motion.li
                    key={item.to}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.04 * i, duration: 0.35 }}
                  >
                    {item.children ? (
                      <div>
                        <button
                          onClick={() => setMobileSubmenu(mobileSubmenu === item.label ? null : item.label)}
                          className="w-full flex items-center justify-between py-3.5 border-b border-espresso/[0.06]"
                        >
                          <span className="font-display text-[1.35rem] text-espresso">{item.label}</span>
                          <ChevronDown className={`w-5 h-5 text-espresso/40 transition-transform duration-300 ${mobileSubmenu === item.label ? 'rotate-180' : ''}`} />
                        </button>
                        <AnimatePresence>
                          {mobileSubmenu === item.label && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="overflow-hidden"
                            >
                              <div className="py-3 pl-4 space-y-0.5">
                                {item.children.map((child, ci) => (
                                  <motion.div
                                    key={child.to}
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: 0.03 * ci, duration: 0.25 }}
                                  >
                                    <NavLink
                                      to={child.to}
                                      className="group flex items-start gap-3 py-2.5 px-3 rounded-xl hover:bg-espresso/[0.04] transition-colors"
                                      onClick={closeMobile}
                                    >
                                      <div className="w-1.5 h-1.5 rounded-full bg-terracotta/40 mt-2 flex-shrink-0 group-hover:bg-terracotta transition-colors" />
                                      <div>
                                        <div className="text-sm font-medium text-espresso group-hover:text-terracotta transition-colors">{child.label}</div>
                                        {child.desc && (
                                          <div className="text-[11px] text-charcoal-warm/60 mt-0.5 leading-relaxed">{child.desc}</div>
                                        )}
                                      </div>
                                    </NavLink>
                                  </motion.div>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    ) : (
                      <NavLink
                        to={item.to}
                        className="block py-3.5 border-b border-espresso/[0.06] font-display text-[1.35rem] text-espresso hover:text-terracotta transition-colors duration-200"
                        end={item.to === '/'}
                        onClick={closeMobile}
                      >
                        {item.label}
                      </NavLink>
                    )}
                  </motion.li>
                ))}
              </ul>
            </div>

            {/* Bottom CTA */}
            <motion.div
              className="px-6 pb-10 pt-6 border-t border-espresso/[0.06]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.3 }}
            >
              <button
                onClick={() => { closeMobile(); openWhatsApp(); }}
                className="w-full py-4 bg-espresso text-cream rounded-2xl text-sm font-medium tracking-wide shadow-sm transition-all duration-300 hover:bg-espresso-light active:scale-[0.98]"
              >
                Join a Class
              </button>
              <p className="text-center text-[11px] text-charcoal-warm/50 mt-4">
                Creative learning for curious minds
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
