import { useState } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import EnquiryModal from '../forms/EnquiryModal';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [isEnquiryOpen, setIsEnquiryOpen] = useState(false);

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar onOpenEnquiry={() => setIsEnquiryOpen(true)} />
      <main className="flex-grow">{children}</main>
      <Footer />
      <EnquiryModal isOpen={isEnquiryOpen} onClose={() => setIsEnquiryOpen(false)} />
    </div>
  );
}
