import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { contactInfo } from '../data/contact';

export default function ContactPage() {
  const infoBlocks = [
    { icon: <MapPin className="w-5 h-5" />, label: 'Studio Location', value: contactInfo.address },
    { icon: <Phone className="w-5 h-5" />, label: 'Phone', value: contactInfo.phone },
    { icon: <Mail className="w-5 h-5" />, label: 'Email', value: contactInfo.email },
  ];

  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[50vh] flex items-end overflow-hidden">
        <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/70 to-cream/30" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40 text-center">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Contact</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1] mb-3">Come Create With Us.</h1>
          <p className="text-charcoal-warm text-sm md:text-base max-w-lg mx-auto">Visit our studio or get in touch. We would love to hear from you.</p>
        </div>
      </section>

      <section className="section-gap bg-cream">
        <div className="container-main">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-4">Get In Touch</span>
              <div className="space-y-4">
                {infoBlocks.map((b, i) => (
                  <motion.div key={b.label} initial={{ opacity: 0, x: -15 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.4, delay: i * 0.08 }}
                    className="flex items-start gap-4 p-5 bg-ivory rounded-2xl border border-espresso/[0.06]">
                    <div className="w-10 h-10 rounded-xl bg-terracotta/8 text-terracotta flex items-center justify-center flex-shrink-0">{b.icon}</div>
                    <div><div className="text-sm font-medium text-espresso mb-0.5">{b.label}</div><div className="text-sm text-charcoal-warm">{b.value}</div></div>
                  </motion.div>
                ))}
                <motion.div initial={{ opacity: 0, x: -15 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.4, delay: 0.24 }}
                  className="flex items-start gap-4 p-5 bg-ivory rounded-2xl border border-espresso/[0.06]">
                  <div className="w-10 h-10 rounded-xl bg-sage/10 text-sage flex items-center justify-center flex-shrink-0"><Clock className="w-5 h-5" /></div>
                  <div>
                    <div className="text-sm font-medium text-espresso mb-1">Studio Hours</div>
                    <div className="text-sm text-charcoal-warm space-y-0.5">
                      <p>Mon - Fri: {contactInfo.hours.weekday}</p>
                      <p>Saturday: {contactInfo.hours.saturday}</p>
                      <p>Sunday: {contactInfo.hours.sunday}</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>

            <div>
              <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-4">Find Us</span>
              <div className="rounded-2xl overflow-hidden aspect-video bg-parchment border border-espresso/[0.06]">
                <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&h=500&fit=crop" alt="Studio location map" loading="lazy" decoding="async" className="w-full h-full object-cover" />
              </div>
               <a href={contactInfo.social.whatsapp} target="_blank" rel="noopener noreferrer"
                className="mt-5 inline-block px-6 py-3 bg-[#25D366] text-white rounded-full text-sm font-medium shadow-[0_4px_16px_rgba(37,211,102,0.25)] hover:shadow-[0_6px_24px_rgba(37,211,102,0.35)] transition-all duration-300">
                Chat on WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
