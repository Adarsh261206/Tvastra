import TestimonialCard from '../components/cards/TestimonialCard';
import { testimonials } from '../data/testimonials';

export default function TestimonialsPage() {
  const parents = testimonials.filter(t => t.role === 'parent');
  const students = testimonials.filter(t => t.role === 'student');

  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[50vh] flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1920&h=1080&fit=crop)' }} />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/70 to-cream/30" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40 text-center">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Testimonials</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1] mb-3">What Our Community Says.</h1>
          <p className="text-charcoal-warm text-sm md:text-base max-w-lg mx-auto">Hear from parents and students who have experienced the TVASTRA difference.</p>
        </div>
      </section>

      <section className="section-gap bg-cream">
        <div className="container-main">
          <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-3">From Parents</span>
          <h2 className="font-display text-2xl md:text-3xl text-espresso leading-[1.1] mb-10">Parent Voices.</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {parents.map((t, i) => <TestimonialCard key={t.id} testimonial={t} delay={i * 0.08} />)}
          </div>
        </div>
      </section>

      <section className="relative section-gap overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1920&h=1080&fit=crop)' }} />
        <div className="absolute inset-0 bg-espresso/85" />
        <div className="relative z-10 container-main">
          <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium mb-3">From Students</span>
          <h2 className="font-display text-2xl md:text-3xl text-cream leading-[1.1] mb-10">Student Voices.</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {students.map((t, i) => <TestimonialCard key={t.id} testimonial={t} delay={i * 0.08} />)}
          </div>
        </div>
      </section>
    </>
  );
}
