import { useState } from 'react';
import { motion } from 'framer-motion';
import ProgramCard from '../components/cards/ProgramCard';
import { programs } from '../data/programs';

interface ProgramsPageProps {
  onOpenEnquiry: (program?: string) => void;
}

export default function ProgramsPage({ onOpenEnquiry }: ProgramsPageProps) {
  const [activeTab, setActiveTab] = useState<'kids' | 'teens' | 'adults'>('kids');
  const tabs = [
    { id: 'kids' as const, label: 'Kids' },
    { id: 'teens' as const, label: 'Teens' },
    { id: 'adults' as const, label: 'Adults' },
  ];

  const active = programs.find(p => p.ageGroup === activeTab);

  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[50vh] flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=1920&h=1080&fit=crop)' }} />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/70 to-cream/30" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40 text-center">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Programs</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1] mb-3">Creative Learning For Every Age.</h1>
          <p className="text-charcoal-warm text-sm md:text-base max-w-lg mx-auto">Programs thoughtfully designed for every stage of your creative journey.</p>
        </div>
      </section>

      <section className="section-gap bg-cream">
        <div className="container-main">
          <div className="flex justify-center gap-3 mb-12">
            {tabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`px-7 py-2.5 rounded-full text-sm font-medium transition-all ${activeTab === tab.id ? 'bg-espresso text-cream' : 'bg-ivory text-charcoal-warm border border-espresso/[0.08] hover:border-espresso/15'}`}>
                {tab.label}
              </button>
            ))}
          </div>

          {active && (
            <motion.div key={active.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}
              className="max-w-2xl mx-auto">
              <ProgramCard program={active} onEnquire={(t) => onOpenEnquiry(t)} />
            </motion.div>
          )}

          <div className="mt-20">
            <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-3">All Programs</span>
            <h2 className="font-display text-2xl md:text-3xl text-espresso leading-[1.1] mb-10">Explore programs across all age groups.</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {programs.map((p, i) => (
                <ProgramCard key={p.id} program={p} delay={i * 0.1} onEnquire={(t) => onOpenEnquiry(t)} />
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
