import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function ArtFormsPage() {
  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[60vh] flex items-end overflow-hidden">
        <img src="https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/60 to-cream/20" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Art Forms</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1]">Traditional & Modern Art.</h1>
        </div>
      </section>

      {/* Two art forms with full images */}
      <section className="section-gap bg-cream">
        <div className="container-main">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Traditional Art */}
            <motion.div initial={{ opacity: 0, x: -15 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
              className="group relative rounded-2xl overflow-hidden">
              <div className="h-80 md:h-[30rem]">
                <img src="https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=800&h=1000&fit=crop" alt="Traditional Art" loading="lazy" decoding="async" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-7 md:p-8">
                <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium">Heritage</span>
                <h2 className="font-display text-2xl md:text-3xl text-cream mt-2 mb-3">Traditional Art</h2>
                <p className="text-cream/70 text-sm leading-relaxed mb-4 max-w-sm">Discover the beauty of traditional artistic techniques passed down through generations. From Madhubani to Warli.</p>
                <div className="flex flex-wrap gap-2">
                  {['Madhubani', 'Warli', 'Mandala', 'Cultural Art'].map((item, i) => (
                    <span key={i} className="px-3 py-1 bg-white/15 backdrop-blur-sm rounded-full text-xs text-cream/80">{item}</span>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Modern Art */}
            <motion.div initial={{ opacity: 0, x: 15 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }}
              className="group relative rounded-2xl overflow-hidden">
              <div className="h-80 md:h-[30rem]">
                <img src="https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800&h=1000&fit=crop" alt="Modern Art" loading="lazy" decoding="async" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-7 md:p-8">
                <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium">Contemporary</span>
                <h2 className="font-display text-2xl md:text-3xl text-cream mt-2 mb-3">Modern Art</h2>
                <p className="text-cream/70 text-sm leading-relaxed mb-4 max-w-sm">Push creative boundaries with abstract expression, mixed media, and contemporary approaches to artistic creation.</p>
                <div className="flex flex-wrap gap-2">
                  {['Abstract Art', 'Mixed Media', 'Fluid Art', 'Resin Art'].map((item, i) => (
                    <span key={i} className="px-3 py-1 bg-white/15 backdrop-blur-sm rounded-full text-xs text-cream/80">{item}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA with background */}
      <section className="relative section-gap overflow-hidden text-center">
        <img src="https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-cream/85" />
        <div className="relative z-10 container-main">
          <p className="font-handwritten text-xl md:text-2xl text-espresso/30 mb-2">Tradition → Technique → Expression</p>
          <p className="font-handwritten text-xl md:text-2xl text-espresso/30 mb-6">Modern → Experimentation → Expression</p>
          <p className="text-charcoal-warm text-sm max-w-lg mx-auto mb-6">
            Whether drawn to timeless tradition or contemporary expression, TVASTRA offers a path for every creative journey.
          </p>
          <Link to="/classes" className="px-7 py-3.5 bg-espresso text-cream rounded-full text-sm font-medium hover:bg-espresso-light transition-all">
            Explore Classes
          </Link>
        </div>
      </section>
    </>
  );
}
