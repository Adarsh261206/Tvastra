import { useState } from 'react';
import GalleryFilter from '../components/gallery/GalleryFilter';
import GalleryGrid from '../components/gallery/GalleryGrid';
import Lightbox from '../components/gallery/Lightbox';
import { galleryItems } from '../data/gallery';
import type { GalleryCategory, GalleryItem } from '../data/gallery';

export default function GalleryPage() {
  const [activeFilter, setActiveFilter] = useState<GalleryCategory | 'all'>('all');
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  const filtered = activeFilter === 'all' ? galleryItems : galleryItems.filter(i => i.category === activeFilter);
  const handlePrev = () => { if (!selectedItem) return; const idx = filtered.findIndex(i => i.id === selectedItem.id); setSelectedItem(filtered[idx > 0 ? idx - 1 : filtered.length - 1]); };
  const handleNext = () => { if (!selectedItem) return; const idx = filtered.findIndex(i => i.id === selectedItem.id); setSelectedItem(filtered[idx < filtered.length - 1 ? idx + 1 : 0]); };

  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[50vh] flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1920&h=1080&fit=crop)' }} />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/70 to-cream/30" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40 text-center">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Gallery</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1] mb-3">Made By Our Students.</h1>
          <p className="text-charcoal-warm text-sm md:text-base max-w-lg mx-auto">A digital exhibition of creative work from our talented students.</p>
        </div>
      </section>

      <section className="section-gap bg-cream">
        <div className="container-main">
          <GalleryFilter active={activeFilter} onChange={setActiveFilter} />
          <GalleryGrid items={filtered} onImageClick={setSelectedItem} />
          {filtered.length === 0 && <div className="text-center py-16"><p className="text-charcoal-warm">No artwork found.</p></div>}
        </div>
        <Lightbox item={selectedItem} items={filtered} onClose={() => setSelectedItem(null)} onPrev={handlePrev} onNext={handleNext} />
      </section>
    </>
  );
}
