import Hero from '../components/home/Hero';
import IntroSection from '../components/home/IntroSection';
import ClassesSection from '../components/home/ClassesSection';
import AgeGroupsSection from '../components/home/AgeGroupsSection';
import ArtFormsSplit from '../components/home/ArtFormsSplit';
import CalligraphySection from '../components/home/CalligraphySection';
import StudentGallery from '../components/home/StudentGallery';
import WorkshopsSection from '../components/home/WorkshopsSection';
import WhyTvasthra from '../components/home/WhyTvasthra';
import TestimonialsSection from '../components/home/TestimonialsSection';
import CtaSection from '../components/home/CtaSection';

interface HomeProps {
  onOpenEnquiry: (program?: string) => void;
}

export default function Home({ onOpenEnquiry }: HomeProps) {
  return (
    <>
      <Hero />
      <IntroSection />
      <ClassesSection />
      <AgeGroupsSection />
      <ArtFormsSplit />
      <CalligraphySection />
      <StudentGallery />
      <WorkshopsSection onOpenEnquiry={onOpenEnquiry} />
      <WhyTvasthra />
      <TestimonialsSection />
      <CtaSection />
    </>
  );
}
