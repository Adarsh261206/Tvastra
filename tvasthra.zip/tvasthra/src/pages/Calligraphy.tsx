import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { openWhatsApp } from '../lib/whatsapp';

interface CalligraphyPageProps {
  onOpenEnquiry?: (program?: string) => void;
}

export default function CalligraphyPage({ onOpenEnquiry: _onOpenEnquiry }: CalligraphyPageProps) {
  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[60vh] flex items-end overflow-hidden">
        <img src="https://images.unsplash.com/photo-1455390582262-044cdead277a?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/60 to-cream/20" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Calligraphy & Handwriting</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1]">Turn Letters Into Art.</h1>
        </div>
      </section>

      {/* Two columns — Calligraphy + Handwriting */}
      <section className="section-gap bg-cream">
        <div className="container-main">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Calligraphy */}
            <motion.div initial={{ opacity: 0, x: -15 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
              className="group relative rounded-2xl overflow-hidden">
              <div className="h-64 md:h-80">
                <img src="https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&h=600&fit=crop" alt="Calligraphy" loading="lazy" decoding="async" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-7">
                <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium">Art of Writing</span>
                <h2 className="font-display text-2xl md:text-3xl text-cream mt-2 mb-3">Calligraphy</h2>
                <p className="text-cream/70 text-sm leading-relaxed mb-4">Explore letterforms, stroke techniques, composition, and both traditional and contemporary calligraphic styles.</p>
                <div className="space-y-1.5">
                  {['Letterform Construction', 'Brush Pen & Cut Nib', 'Traditional & Modern Styles'].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-cream/60 text-xs"><Check className="w-3 h-3 text-terracotta-light" />{item}</div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Handwriting */}
            <motion.div initial={{ opacity: 0, x: 15 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }}
              className="group relative rounded-2xl overflow-hidden">
              <div className="h-64 md:h-80">
                <img src="https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&h=600&fit=crop&q=90" alt="Handwriting" loading="lazy" decoding="async" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-7">
                <span className="text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium">Beautiful Writing</span>
                <h2 className="font-display text-2xl md:text-3xl text-cream mt-2 mb-3">Handwriting</h2>
                <p className="text-cream/70 text-sm leading-relaxed mb-4">Improve your handwriting through structured practice. Develop legible, consistent, and confident writing.</p>
                <div className="space-y-1.5">
                  {['Letter Consistency', 'Cursive & Print', 'Speed & Neatness'].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-cream/60 text-xs"><Check className="w-3 h-3 text-terracotta-light" />{item}</div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Who Can Join — with background */}
      <section className="relative section-gap overflow-hidden">
        <img src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-cream/90" />
        <div className="relative z-10 container-main text-center">
          <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-4">Who Can Join</span>
          <h2 className="font-display text-3xl md:text-4xl text-espresso leading-[1.1] mb-10">Open to Everyone.</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[{ t: 'Kids', d: 'Age-appropriate lettering programs.', img: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=400&h=400&fit=crop' }, { t: 'Teens', d: 'Skill development in calligraphy.', img: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=400&h=400&fit=crop' }, { t: 'Adults', d: 'Personal enrichment through beautiful writing.', img: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=400&h=400&fit=crop' }].map((g, i) => (
              <motion.div key={g.t} initial={{ opacity: 0, y: 15 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.4, delay: i * 0.08 }}
                className="group relative rounded-2xl overflow-hidden aspect-[3/4]">
                <img src={g.img} alt={g.t} loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-left">
                  <h3 className="font-display text-2xl text-cream mb-1">{g.t}</h3>
                  <p className="text-cream/70 text-sm">{g.d}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-gap bg-espresso text-center">
        <div className="container-main">
          <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium mb-4">Get Started</span>
          <h2 className="font-display text-2xl md:text-3xl text-cream mb-5">Enquire About Calligraphy.</h2>
          <button onClick={() => openWhatsApp('Calligraphy')} className="px-7 py-3.5 bg-terracotta text-white rounded-full text-sm font-medium hover:bg-terracotta-deep transition-all">
            Send an Enquiry
          </button>
        </div>
      </section>
    </>
  );
}
