import { useState } from 'react';
import ClassCard from '../components/cards/ClassCard';
import { classes } from '../data/classes';

const categories = [
  { id: 'all', label: 'All' },
  { id: 'drawing', label: 'Drawing' },
  { id: 'painting', label: 'Painting' },
  { id: 'calligraphy', label: 'Calligraphy' },
  { id: 'handwriting', label: 'Handwriting' },
  { id: 'traditional', label: 'Traditional Art' },
  { id: 'modern', label: 'Modern Art' },
];

interface ClassesPageProps {
  onOpenEnquiry: (program?: string) => void;
}

export default function ClassesPage({ onOpenEnquiry }: ClassesPageProps) {
  const [active, setActive] = useState('all');

  const filtered = active === 'all'
    ? classes
    : classes.filter(c => c.slug.includes(active) || (active === 'traditional' && c.slug === 'traditional-art') || (active === 'modern' && c.slug === 'modern-art'));

  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[50vh] flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=1920&h=1080&fit=crop)' }} />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/70 to-cream/30" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40 text-center">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Our Classes</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1] mb-3">Explore Our Classes.</h1>
          <p className="text-charcoal-warm text-sm md:text-base max-w-lg mx-auto">Find the perfect class for your creative journey.</p>
        </div>
      </section>

      {/* Classes grid */}
      <section className="section-gap bg-cream">
        <div className="container-main">
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {categories.map(cat => (
              <button key={cat.id} onClick={() => setActive(cat.id)}
                className={`px-5 py-2 rounded-full text-xs tracking-wide transition-all ${active === cat.id ? 'bg-espresso text-cream' : 'bg-ivory text-charcoal-warm border border-espresso/[0.08] hover:border-espresso/15'}`}>
                {cat.label}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
            {filtered.map((cls, i) => (
              <ClassCard key={cls.id} cls={cls} delay={i * 0.08} onEnquire={(n) => onOpenEnquiry(n)} />
            ))}
          </div>
          {filtered.length === 0 && (
            <div className="text-center py-16"><p className="text-charcoal-warm">No classes found in this category.</p></div>
          )}
        </div>
      </section>
    </>
  );
}
