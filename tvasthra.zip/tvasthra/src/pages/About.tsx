import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function About() {
  const principles = [
    { num: '01', title: 'Explore', description: 'Students discover different creative forms, materials, and techniques with curiosity and open-mindedness.' },
    { num: '02', title: 'Practice', description: 'Skills develop through consistent hands-on work. Regular practice builds confidence and artistic understanding.' },
    { num: '03', title: 'Express', description: 'Students learn to communicate ideas and emotions through art. Self-expression is the ultimate goal.' },
  ];

  return (
    <>
      {/* Hero with background image */}
      <section className="relative min-h-[70vh] flex items-end overflow-hidden">
        <img src="https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/60 to-cream/20" />
        <div className="relative z-10 container-main pb-16 md:pb-24 pt-32 md:pt-40">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">About TVASTRA</span>
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1] mb-4">
              The Story Behind<br />The Studio.
            </h1>
          </motion.div>
        </div>
      </section>

      {/* Story section with image */}
      <section className="section-gap bg-cream">
        <div className="container-main">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }} className="relative">
              <div className="rounded-2xl overflow-hidden aspect-[4/5]">
                <img src="https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=800&h=1000&fit=crop" alt="Creative learning environment" loading="lazy" decoding="async" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-5 -right-5 w-28 h-28 rounded-2xl bg-terracotta/8 -z-10" />
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.7, delay: 0.15 }}>
              <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-4">Our Story</span>
              <h2 className="font-display text-3xl md:text-4xl text-espresso leading-[1.1] mb-5">What is TVASTRA?</h2>
              <p className="text-charcoal-warm text-sm leading-relaxed mb-4">
                TVASTRA is an offline creative learning and art studio that provides a nurturing environment for kids, teens, and adults to explore various forms of art. We offer classes, workshops, and creative programs designed to develop artistic skills while fostering creativity and self-expression.
              </p>
              <p className="text-charcoal-warm text-sm leading-relaxed mb-8">
                Our studio is built on the belief that everyone has creative potential. Through guided instruction, hands-on practice, and a supportive community, we help our students unlock their artistic abilities.
              </p>
              <div className="grid grid-cols-3 gap-4 py-5 border-y border-espresso/[0.08]">
                <div>
                  <div className="text-[10px] tracking-[0.15em] uppercase text-terracotta font-medium mb-1">Hands-On</div>
                  <div className="font-display text-sm md:text-base text-espresso">Creative Learning</div>
                </div>
                <div>
                  <div className="text-[10px] tracking-[0.15em] uppercase text-terracotta font-medium mb-1">Multiple</div>
                  <div className="font-display text-sm md:text-base text-espresso">Art Forms</div>
                </div>
                <div>
                  <div className="text-[10px] tracking-[0.15em] uppercase text-terracotta font-medium mb-1">All Ages</div>
                  <div className="font-display text-sm md:text-base text-espresso">Welcome</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Principles with background */}
      <section className="relative section-gap overflow-hidden">
        <img src="https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-cream/90" />
        <div className="relative z-10 container-main">
          <div className="text-center mb-14">
            <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-4">Our Philosophy</span>
            <h2 className="font-display text-3xl md:text-4xl text-espresso leading-[1.1]">Three Principles Guide<br />Everything We Do.</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {principles.map((p, i) => (
              <motion.div key={p.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}
                className="bg-ivory/80 backdrop-blur-sm p-8 rounded-2xl border border-espresso/[0.06]">
                <span className="font-display text-3xl text-terracotta/20">{p.num}</span>
                <h3 className="font-display text-xl text-espresso mt-3 mb-3">{p.title}</h3>
                <p className="text-charcoal-warm text-sm leading-relaxed">{p.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Age groups with background image */}
      <section className="relative section-gap overflow-hidden">
        <img src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=1920&h=1080&fit=crop" alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-espresso/80" />
        <div className="relative z-10 container-main text-center">
          <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta-light font-medium mb-4">Who We Teach</span>
          <h2 className="font-display text-3xl md:text-4xl text-cream leading-[1.1] mb-12">Programs Designed For Every Stage.</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[{ t: 'Kids', d: 'Building creativity and a love for art through guided, fun activities.', img: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=400&h=400&fit=crop' }, { t: 'Teens', d: 'Developing real artistic skills, personal style, and creative confidence.', img: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=400&h=400&fit=crop' }, { t: 'Adults', d: 'Exploring new creative outlets and finding joy in artistic expression.', img: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=400&h=400&fit=crop' }].map((g, i) => (
              <motion.div key={g.t} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}
                className="group relative rounded-2xl overflow-hidden aspect-[3/4]">
                <img src={g.img} alt={g.t} loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-espresso/80 via-espresso/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-left">
                  <h3 className="font-display text-2xl text-cream mb-2">{g.t}</h3>
                  <p className="text-cream/70 text-sm">{g.d}</p>
                </div>
              </motion.div>
            ))}
          </div>
          <Link to="/classes" className="mt-12 px-7 py-3.5 bg-terracotta text-white rounded-full text-sm font-medium hover:bg-terracotta-deep transition-all">
            Start Your Journey
          </Link>
        </div>
      </section>
    </>
  );
}
