import WorkshopCard from '../components/cards/WorkshopCard';
import { workshops } from '../data/workshops';

interface WorkshopsPageProps {
  onOpenEnquiry: (title?: string) => void;
}

export default function WorkshopsPage({ onOpenEnquiry }: WorkshopsPageProps) {
  const upcoming = workshops.filter(w => w.status === 'upcoming');
  const completed = workshops.filter(w => w.status === 'completed');

  return (
    <>
      {/* Hero with background */}
      <section className="relative min-h-[50vh] flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=1920&h=1080&fit=crop)' }} />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/70 to-cream/30" />
        <div className="relative z-10 container-main pb-12 md:pb-16 pt-32 md:pt-40 text-center">
          <span className="inline-block text-[10px] sm:text-[11px] tracking-[0.25em] uppercase text-terracotta font-medium mb-4">Workshops</span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-espresso leading-[1.1] mb-3">More Than Just Classes.</h1>
          <p className="text-charcoal-warm text-sm md:text-base max-w-lg mx-auto">Special creative experiences that bring our community together.</p>
        </div>
      </section>

      {upcoming.length > 0 && (
        <section className="section-gap bg-cream">
          <div className="container-main">
            <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-3">Upcoming</span>
            <h2 className="font-display text-2xl md:text-3xl text-espresso leading-[1.1] mb-10">Upcoming Workshops.</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {upcoming.map((w, i) => <WorkshopCard key={w.id} workshop={w} delay={i * 0.08} onEnquire={(t) => onOpenEnquiry(t)} />)}
            </div>
          </div>
        </section>
      )}
      {completed.length > 0 && (
        <section className="section-gap bg-cream-warm">
          <div className="container-main">
            <span className="inline-block text-[10px] tracking-[0.2em] uppercase text-terracotta font-medium mb-3">Past Events</span>
            <h2 className="font-display text-2xl md:text-3xl text-espresso leading-[1.1] mb-10">Past Workshops.</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {completed.map((w, i) => <WorkshopCard key={w.id} workshop={w} delay={i * 0.08} />)}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
