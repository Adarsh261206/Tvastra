export interface Testimonial {
  id: string;
  quote: string;
  name: string;
  role: 'parent' | 'student';
  ageGroup?: string;
  program?: string;
}

export const testimonials: Testimonial[] = [
  {
    id: 't1',
    quote: 'My daughter looks forward to every class at TVASTRA. The instructors are patient, encouraging, and genuinely passionate about helping each child express their creativity.',
    name: '[Parent Name]',
    role: 'parent',
    ageGroup: 'Kids',
    program: 'Drawing & Painting'
  },
  {
    id: 't2',
    quote: 'I always wanted to learn calligraphy, and TVASTRA made it possible. The studio environment is warm and inspiring. I have discovered a skill I never knew I had.',
    name: '[Student Name]',
    role: 'student',
    ageGroup: 'Adults',
    program: 'Calligraphy'
  },
  {
    id: 't3',
    quote: 'TVASTRA has helped my son develop not just artistic skills, but confidence and patience. The workshops are especially wonderful — full of energy and creativity.',
    name: '[Parent Name]',
    role: 'parent',
    ageGroup: 'Teens',
    program: 'Modern Art'
  },
  {
    id: 't4',
    quote: 'The studio feels like a community of creators. Every session brings something new, and the instructors really understand how to bring out the best in each student.',
    name: '[Student Name]',
    role: 'student',
    ageGroup: 'Teens',
    program: 'Drawing & Sketching'
  },
  {
    id: 't5',
    quote: 'Both my children attend TVASTRA and the transformation in their creativity and confidence has been remarkable. The classes are well-structured and the atmosphere is wonderful.',
    name: '[Parent Name]',
    role: 'parent',
    ageGroup: 'Kids',
    program: 'Creative Activities'
  },
  {
    id: 't6',
    quote: 'As someone who never thought of themselves as creative, joining TVASTRA as an adult was one of the best decisions I have made. I have found a whole new way to express myself.',
    name: '[Student Name]',
    role: 'student',
    ageGroup: 'Adults',
    program: 'Painting'
  }
];
