export const contactInfo = {
  address: '[Studio Address]',
  phone: '[Phone Number]',
  email: '[Email Address]',
  hours: {
    weekday: '[Weekday Hours]',
    saturday: '[Saturday Hours]',
    sunday: '[Sunday Hours]'
  },
  social: {
    instagram: '#',
    facebook: '#',
    youtube: '#',
    whatsapp: 'https://wa.me/918530477609'
  },
  mapEmbedUrl: '[Google Maps Embed URL]'
};
