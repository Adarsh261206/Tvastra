export interface Workshop {
  id: string;
  title: string;
  type: string;
  description: string;
  date: string;
  duration: string;
  ageGroup: string;
  image: string;
  status: 'upcoming' | 'completed';
}

export const workshops: Workshop[] = [
  {
    id: 'w1',
    title: 'Weekend Art Workshop',
    type: 'Weekend Session',
    description: 'A focused creative session exploring a specific art technique in a single day. Perfect for trying something new.',
    date: '[Workshop Date]',
    duration: '[Duration]',
    ageGroup: 'All Ages',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=600&h=400&fit=crop',
    status: 'upcoming'
  },
  {
    id: 'w2',
    title: 'Holiday Creative Camp',
    type: 'Holiday Program',
    description: 'An immersive creative experience during school holidays. Multiple art forms, projects, and creative activities.',
    date: '[Workshop Date]',
    duration: '[Duration]',
    ageGroup: 'Kids & Teens',
    image: 'https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=600&h=400&fit=crop',
    status: 'upcoming'
  },
  {
    id: 'w3',
    title: 'Calligraphy Intensive',
    type: 'Special Workshop',
    description: 'A deep dive into the art of beautiful lettering. Learn stroke techniques, letterforms, and composition.',
    date: '[Workshop Date]',
    duration: '[Duration]',
    ageGroup: 'Teens & Adults',
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=400&fit=crop',
    status: 'upcoming'
  },
  {
    id: 'w4',
    title: 'Traditional Art Exploration',
    type: 'Cultural Workshop',
    description: 'Discover the beauty and history of traditional Indian art forms in this hands-on workshop.',
    date: '[Workshop Date]',
    duration: '[Duration]',
    ageGroup: 'All Ages',
    image: 'https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=600&h=400&fit=crop',
    status: 'completed'
  },
  {
    id: 'w5',
    title: 'Modern Art Experiment',
    type: 'Creative Workshop',
    description: 'Push creative boundaries with abstract techniques, mixed media, and contemporary art approaches.',
    date: '[Workshop Date]',
    duration: '[Duration]',
    ageGroup: 'Teens & Adults',
    image: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=600&h=400&fit=crop',
    status: 'completed'
  },
  {
    id: 'w6',
    title: 'Parent & Child Art Session',
    type: 'Family Workshop',
    description: 'A special creative experience designed for parents and children to create art together.',
    date: '[Workshop Date]',
    duration: '[Duration]',
    ageGroup: 'Families',
    image: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=600&h=400&fit=crop',
    status: 'completed'
  }
];
