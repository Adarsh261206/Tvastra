export type GalleryCategory = 'drawing' | 'painting' | 'calligraphy' | 'crafts' | 'modern-art' | 'workshops';

export interface GalleryItem {
  id: string;
  title: string;
  category: GalleryCategory;
  studentName: string;
  description: string;
  image: string;
  aspect: 'portrait' | 'landscape' | 'square';
}

export const galleryCategories: { id: GalleryCategory | 'all'; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'drawing', label: 'Drawing' },
  { id: 'painting', label: 'Painting' },
  { id: 'calligraphy', label: 'Calligraphy' },
  { id: 'crafts', label: 'Craft' },
  { id: 'modern-art', label: 'Modern Art' },
  { id: 'workshops', label: 'Workshops' },
];

export const galleryItems: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Landscape in Pencil',
    category: 'drawing',
    studentName: '[Student Name]',
    description: 'A detailed pencil study exploring light, shadow, and natural composition.',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=600&h=400&fit=crop',
    aspect: 'landscape'
  },
  {
    id: 'g2',
    title: 'Watercolor Abstract',
    category: 'painting',
    studentName: '[Student Name]',
    description: 'An expressive watercolor exploring color flow and movement.',
    image: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=600&h=600&fit=crop',
    aspect: 'square'
  },
  {
    id: 'g3',
    title: 'Brush Lettering Quote',
    category: 'calligraphy',
    studentName: '[Student Name]',
    description: 'Brush calligraphy featuring an inspirational quote.',
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=800&fit=crop',
    aspect: 'portrait'
  },
  {
    id: 'g4',
    title: 'Charcoal Still Life',
    category: 'drawing',
    studentName: '[Student Name]',
    description: 'Charcoal study of everyday objects with dramatic tonal contrast.',
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=600&h=800&fit=crop',
    aspect: 'portrait'
  },
  {
    id: 'g5',
    title: 'Traditional Pattern',
    category: 'crafts',
    studentName: '[Student Name]',
    description: 'Intricate pattern art inspired by traditional cultural motifs.',
    image: 'https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=600&h=400&fit=crop',
    aspect: 'landscape'
  },
  {
    id: 'g6',
    title: 'Fluid Art Piece',
    category: 'modern-art',
    studentName: '[Student Name]',
    description: 'Fluid art exploring organic color interaction and pattern.',
    image: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=600&h=600&fit=crop',
    aspect: 'square'
  },
  {
    id: 'g7',
    title: 'Nature Sketches',
    category: 'drawing',
    studentName: '[Student Name]',
    description: 'Botanical sketches drawn from direct observation.',
    image: 'https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=600&h=800&fit=crop',
    aspect: 'portrait'
  },
  {
    id: 'g8',
    title: 'Acrylic Landscape',
    category: 'painting',
    studentName: '[Student Name]',
    description: 'Acrylic landscape exploring atmosphere and color harmony.',
    image: 'https://images.unsplash.com/photo-1596548438137-d51ea5c83ca5?w=600&h=400&fit=crop',
    aspect: 'landscape'
  },
  {
    id: 'g9',
    title: 'Workshop Project',
    category: 'workshops',
    studentName: '[Student Name]',
    description: 'Artwork created during a special creative workshop session.',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=600&h=600&fit=crop&q=80',
    aspect: 'square'
  },
  {
    id: 'g10',
    title: 'Mixed Media Collage',
    category: 'modern-art',
    studentName: '[Student Name]',
    description: 'A layered collage combining paper, paint, and found materials.',
    image: 'https://images.unsplash.com/photo-1482160549825-59d1b23cb208?w=600&h=800&fit=crop&q=80',
    aspect: 'portrait'
  },
  {
    id: 'g11',
    title: 'Ink Lettering',
    category: 'calligraphy',
    studentName: '[Student Name]',
    description: 'Traditional ink calligraphy exploring classical letterforms.',
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&h=400&fit=crop&q=90',
    aspect: 'landscape'
  },
  {
    id: 'g12',
    title: 'Color Theory Study',
    category: 'painting',
    studentName: '[Student Name]',
    description: 'Exploring color harmonies and contrasts through paint.',
    image: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=600&h=600&fit=crop&q=85',
    aspect: 'square'
  }
];
